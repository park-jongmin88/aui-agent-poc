# AI-Studio 포탈 (React 데모)

DB·서버 없이 목데이터로 동작하는 프론트엔드 데모.

## 실행
```bash
npm install
npm run dev
```
브라우저에서 http://localhost:5173 자동 오픈.

## 구조
```
src/
├─ mock/data.js      # 목데이터 (실제 API 연동 시 이 파일만 교체)
├─ components/       # Lnb, Layout, Modal 등 공통
├─ pages/            # 빌더선택 / 폼·코드·플로우 빌더 / 관리자4종 / 서빙·플그·평가
├─ App.jsx           # 라우팅
└─ styles.css        # 전체 스타일
```

## 플로우 빌더 (Flowise)
플로우 빌더 화면의 "Flowise 연결 보기" 버튼 → 안내대로 Flowise를 띄우고
`src/pages/FlowBuilder.jsx`의 `FLOWISE_URL`에 주소를 넣으면 iframe 임베드됩니다.
```bash
docker run -d -p 3000:3000 flowiseai/flowise
```
