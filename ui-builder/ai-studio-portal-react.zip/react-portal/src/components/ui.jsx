import Lnb from "./Lnb";

export function Layout({ children }) {
  return (
    <div className="app">
      <Lnb />
      <main className="main">{children}</main>
    </div>
  );
}

export function PageHead({ eyebrow, title, sub, right }) {
  return (
    <div className="page-head">
      {eyebrow && <p className="eyebrow">{eyebrow}</p>}
      <div className="head-row">
        <div>
          <h1 className="h1" style={{ marginBottom: sub ? 8 : 0 }}>{title}</h1>
          {sub && <p className="sub">{sub}</p>}
        </div>
        {right}
      </div>
    </div>
  );
}

export function Modal({ title, open, onClose, children, onSubmit, submitLabel = "등록" }) {
  if (!open) return null;
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <span className="modal-title">{title}</span>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <div className="modal-body">{children}</div>
        <div className="modal-foot">
          <button className="btn btn-ghost" onClick={onClose}>취소</button>
          <button className="btn btn-primary" onClick={onSubmit}>{submitLabel}</button>
        </div>
      </div>
    </div>
  );
}

export function Field({ label, children }) {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      {children}
    </label>
  );
}

export function Tag({ tone = "gray", children }) {
  return <span className={`tag tag-${tone}`}>{children}</span>;
}
