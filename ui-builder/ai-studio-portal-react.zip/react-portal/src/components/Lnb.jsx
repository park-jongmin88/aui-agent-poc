import { useState } from "react";
import { NavLink, useLocation } from "react-router-dom";

export const NAV = [
  { id: "admin", label: "관리자", children: [
    { to: "/admin/prompt", label: "프롬프트 관리" },
    { to: "/admin/rag", label: "RAG 관리" },
    { to: "/admin/tool", label: "도구(Tool) 관리" },
    { to: "/admin/model", label: "LLM 모델 관리" },
  ]},
  { id: "builder", label: "빌더", children: [
    { to: "/", label: "빌더 선택", end: true },
    { to: "/builder/form", label: "폼 빌더" },
    { to: "/builder/code", label: "코드 빌더" },
    { to: "/builder/flow", label: "플로우 빌더" },
  ]},
  { id: "serving", label: "서빙", children: [
    { to: "/serving", label: "배포 관리" },
  ]},
  { id: "playground", label: "플레이그라운드", children: [
    { to: "/playground", label: "대화 테스트" },
  ]},
  { id: "eval", label: "평가", children: [
    { to: "/eval", label: "Judge 평가" },
  ]},
];

export default function Lnb() {
  const { pathname } = useLocation();

  // 현재 경로가 속한 그룹을 기본 펼침
  const groupOfPath = NAV.find((g) =>
    g.children.some((c) => (c.end ? pathname === c.to : pathname.startsWith(c.to) && c.to !== "/"))
    || (pathname === "/" && g.id === "builder")
  )?.id;

  const [open, setOpen] = useState(() => {
    const init = {};
    NAV.forEach((g) => (init[g.id] = g.id === groupOfPath));
    return init;
  });

  const toggle = (id) => setOpen((o) => ({ ...o, [id]: !o[id] }));

  return (
    <aside className="lnb">
      <div className="lnb-brand">AI-Studio</div>
      <nav className="lnb-nav">
        {NAV.map((g) => (
          <div key={g.id}>
            <button
              className={"lnb-group" + (open[g.id] ? " open" : "")}
              onClick={() => toggle(g.id)}
            >
              <span>{g.label}</span>
              <span className="lnb-caret">›</span>
            </button>
            {open[g.id] && (
              <div className="lnb-sub">
                {g.children.map((c) => (
                  <NavLink
                    key={c.to}
                    to={c.to}
                    end={c.end}
                    className={({ isActive }) => "lnb-item" + (isActive ? " active" : "")}
                  >
                    {c.label}
                  </NavLink>
                ))}
              </div>
            )}
          </div>
        ))}
      </nav>
    </aside>
  );
}
