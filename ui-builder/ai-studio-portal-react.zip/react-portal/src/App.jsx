import { BrowserRouter, Routes, Route } from "react-router-dom";
import BuilderSelect from "./pages/BuilderSelect";
import FormBuilder from "./pages/FormBuilder";
import CodeBuilder from "./pages/CodeBuilder";
import FlowBuilder from "./pages/FlowBuilder";
import AdminPrompt from "./pages/AdminPrompt";
import AdminRag from "./pages/AdminRag";
import AdminTool from "./pages/AdminTool";
import AdminModel from "./pages/AdminModel";
import Serving from "./pages/Serving";
import Playground from "./pages/Playground";
import Eval from "./pages/Eval";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<BuilderSelect />} />
        <Route path="/builder/form" element={<FormBuilder />} />
        <Route path="/builder/code" element={<CodeBuilder />} />
        <Route path="/builder/flow" element={<FlowBuilder />} />
        <Route path="/admin/prompt" element={<AdminPrompt />} />
        <Route path="/admin/rag" element={<AdminRag />} />
        <Route path="/admin/tool" element={<AdminTool />} />
        <Route path="/admin/model" element={<AdminModel />} />
        <Route path="/serving" element={<Serving />} />
        <Route path="/playground" element={<Playground />} />
        <Route path="/eval" element={<Eval />} />
      </Routes>
    </BrowserRouter>
  );
}
