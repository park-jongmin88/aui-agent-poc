import { Layout, PageHead, Tag } from "../components/ui";
import { evaluations, evalSummary } from "../mock/data";

export default function Eval() {
  return (
    <Layout>
      <PageHead eyebrow="평가" title="Judge 평가"
        sub="MLflow make_judge로 에이전트 응답 품질을 평가합니다."
        right={<button className="btn btn-primary" onClick={() => alert("데모: 새 평가 실행")}>+ 평가 실행</button>} />

      <div className="eval-cards">
        {evalSummary.map((s) => (
          <div key={s.label} className="eval-stat">
            <span className="es-label">{s.label}</span>
            <span className="es-val" style={{ color: s.color }}>{s.value}</span>
            <span className="es-max">/ 5.0</span>
          </div>
        ))}
      </div>

      <div className="card-box">
        <table>
          <thead><tr><th>평가 ID</th><th>에이전트</th><th>샘플 수</th><th>평균 점수</th><th>실행일</th><th style={{ width: 90 }}></th></tr></thead>
          <tbody>
            {evaluations.map((r) => (
              <tr key={r.id}>
                <td className="mono-sm" style={{ fontWeight: 600 }}>{r.id}</td>
                <td>{r.agent}</td>
                <td className="muted">{r.samples}건</td>
                <td><Tag tone={r.score >= 4.2 ? "green" : "amber"}>{r.score.toFixed(1)}</Tag></td>
                <td className="muted">{r.ran}</td>
                <td><button className="btn btn-ghost btn-sm" onClick={() => alert("데모: 리포트")}>리포트</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  );
}
