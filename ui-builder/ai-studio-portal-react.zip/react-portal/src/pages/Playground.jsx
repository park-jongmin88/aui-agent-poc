import { Layout, PageHead } from "../components/ui";

export default function Playground() {
  return (
    <Layout>
      <PageHead eyebrow="플레이그라운드" title="대화 테스트"
        sub="배포된 에이전트와 직접 대화하며 동작을 확인합니다." />
      <div className="pg-wrap">
        <div className="pg-bar">
          <label className="field" style={{ flex: 1 }}>
            <span className="field-label">에이전트 선택</span>
            <select className="input"><option>customer-agent (v3)</option><option>doc-qa-agent (v2)</option></select>
          </label>
        </div>
        <div className="pg-chat">
          <div className="msg user"><div className="bubble">환불 규정이 어떻게 되나요?</div></div>
          <div className="msg bot"><div className="bubble">
            환불은 구매일로부터 14일 이내 가능합니다. 단순 변심의 경우 왕복 배송비가 부과되며,
            제품 하자 시에는 전액 환불 및 무료 회수가 진행됩니다.
            <div className="trace">📚 RAG: 제품_매뉴얼 · 2건 참조 · 1.2s</div>
          </div></div>
          <div className="msg user"><div className="bubble">배송비는 얼마인가요?</div></div>
          <div className="msg bot"><div className="bubble">
            기본 배송비는 3,000원이며 5만원 이상 구매 시 무료입니다.
            <div className="trace">⚙ Tool: 배송비조회 · 0.8s</div>
          </div></div>
        </div>
        <div className="pg-input">
          <input className="input" placeholder="메시지를 입력하세요..." style={{ flex: 1 }} />
          <button className="btn btn-primary" onClick={() => alert("데모: 전송")}>전송</button>
        </div>
      </div>
    </Layout>
  );
}
