import { useNavigate } from "react-router-dom";
import { Layout, PageHead } from "../components/ui";

const CARDS = [
  { to: "/builder/form", step: "01", title: "폼 빌더", who: "처음 만드는 사용자",
    tagline: "클릭으로 만드는 가장 쉬운 길",
    desc: "프롬프트, RAG, 도구, 모델을 폼에서 선택하면 에이전트가 구성됩니다. 코드를 몰라도 됩니다.",
    points: ["에셋 선택 → 자동 구성", "설정 실시간 미리보기", "코드 작성 불필요"],
    accent: "#60a5fa", soft: "#eff6ff" },
  { to: "/builder/code", step: "02", title: "코드 빌더", who: "코드에 익숙한 개발자",
    tagline: "직접 손대고 싶은 사람을 위한",
    desc: "웹 편집기에서 에이전트 코드를 직접 수정합니다. 세밀한 제어가 필요할 때 사용합니다.",
    points: ["에이전트 코드 직접 편집", "에셋 로직 커스터마이즈", "터미널·실행 환경 내장"],
    accent: "#a78bfa", soft: "#f5f3ff" },
  { to: "/builder/flow", step: "03", title: "플로우 빌더", who: "흐름 중심의 기획자",
    tagline: "흐름을 눈으로 그리는 방식",
    desc: "노드를 연결해 에이전트 동작 흐름을 시각적으로 설계합니다. 구조를 한눈에 보며 만듭니다.",
    points: ["노드 드래그로 연결", "분기·순서 시각화", "흐름 그대로 에이전트화"],
    accent: "#2dd4bf", soft: "#f0fdfa" },
];

export default function BuilderSelect() {
  const nav = useNavigate();
  return (
    <Layout>
      <PageHead eyebrow="에이전트 빌더" title="어떤 방식으로 만들까요?"
        sub="세 방식 모두 같은 에이전트를 만듭니다. 익숙한 방법을 고르세요." />
      <div className="select-row">
        {CARDS.map((c) => (
          <div key={c.to} className="select-card"
            style={{ "--accent": c.accent, "--soft": c.soft }}
            onClick={() => nav(c.to)}>
            <div className="sc-top">
              <span className="sc-step">{c.step}</span>
              <span className="sc-who">{c.who}</span>
            </div>
            <h2 className="sc-title">{c.title}</h2>
            <p className="sc-tagline">{c.tagline}</p>
            <p className="sc-desc">{c.desc}</p>
            <ul className="sc-points">
              {c.points.map((p, i) => <li key={i}><span className="sc-dot" />{p}</li>)}
            </ul>
            <div className="sc-cta">이 방식으로 시작 <span className="sc-arrow">→</span></div>
          </div>
        ))}
      </div>
    </Layout>
  );
}
