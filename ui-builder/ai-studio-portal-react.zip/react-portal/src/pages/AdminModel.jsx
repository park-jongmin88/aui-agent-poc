import { useState } from "react";
import { Layout, PageHead, Modal, Field, Tag } from "../components/ui";
import { models } from "../mock/data";

export default function AdminModel() {
  const [open, setOpen] = useState(false);
  return (
    <Layout>
      <PageHead eyebrow="관리자" title="LLM 모델 관리"
        sub="에이전트가 사용할 LLM 모델 엔드포인트를 등록·관리합니다."
        right={<button className="btn btn-primary" onClick={() => setOpen(true)}>+ 모델 등록</button>} />

      <div className="card-box">
        <table>
          <thead><tr><th>모델명</th><th>base_url</th><th>상태</th><th>등록일</th><th style={{ width: 90 }}></th></tr></thead>
          <tbody>
            {models.map((r) => (
              <tr key={r.id}>
                <td style={{ fontWeight: 600 }}>{r.name}</td>
                <td className="mono-sm">{r.baseUrl}</td>
                <td><Tag tone={r.status === "정상" ? "green" : "amber"}>{r.status}</Tag></td>
                <td className="muted">{r.created}</td>
                <td><button className="btn btn-ghost btn-sm" onClick={() => alert("데모: 관리")}>관리</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Modal title="LLM 모델 등록" open={open} onClose={() => setOpen(false)}
        onSubmit={() => { setOpen(false); alert("데모: 모델 등록됨"); }}>
        <Field label="모델명"><input className="input" placeholder="예: Qwen2.5-72B" /></Field>
        <Field label="base_url"><input className="input" placeholder="http://vllm-server:8000/v1" /></Field>
        <Field label="API Key (선택)"><input className="input" type="password" placeholder="••••••••" /></Field>
      </Modal>
    </Layout>
  );
}
