import { useNavigate } from "react-router-dom";
import { Layout } from "../components/ui";

const ACCENT = "#a78bfa";
const FILES = [
  { name: "agent.py", active: true }, { name: "config.py" },
  { name: "assets/", dir: true },
  { name: "prompt.py", indent: true }, { name: "rag.py", indent: true },
  { name: "tool.py", indent: true }, { name: "llm.py", indent: true },
  { name: "requirements.txt" },
];
const CODE = `"""
AI-Studio | GenAI Agent (agent.py)
ModelWrapper 와 config 를 조립해 MLflow pyfunc 로 등록한다.
"""
import mlflow
from config import ENABLED_ASSETS, MLFLOW_CONN, LLM_MODEL
from aiu_custom.predict import ModelWrapper


def register_agent():
    mlflow.set_tracking_uri(MLFLOW_CONN["tracking_uri"])
    mlflow.set_experiment(MLFLOW_CONN["experiment_name"])

    with mlflow.start_run(run_name="agent-register") as run:
        mlflow.log_params({"assets": ",".join(ENABLED_ASSETS)})
        model_info = mlflow.pyfunc.log_model(
            name="genai_agent",
            python_model=ModelWrapper(),
            code_paths=["aiu_custom", "config.py", "assets"],
        )
        print("등록 완료:", model_info.model_uri)


if __name__ == "__main__":
    register_agent()`;

export default function CodeBuilder() {
  const nav = useNavigate();
  return (
    <Layout>
      <div className="page-head">
        <button className="back-link" onClick={() => nav("/")}>← 방식 선택</button>
        <div className="head-row">
          <div className="bhead-title">
            <span className="bhead-step" style={{ color: ACCENT }}>02</span>
            <h1 className="h1" style={{ margin: 0 }}>코드 빌더</h1>
            <span className="sc-who" style={{ background: "#f5f3ff", color: ACCENT }}>코드에 익숙한 개발자</span>
          </div>
          <button className="btn btn-primary" style={{ background: ACCENT }}
            onClick={() => alert("데모: python agent.py 실행")}>실행 ▷</button>
        </div>
      </div>

      <div className="ide">
        <div className="ide-tree">
          <div className="ide-tree-head">탐색기</div>
          {FILES.map((f, i) => (
            <div key={i} className={"tree-item" + (f.active ? " active" : "") + (f.dir ? " dir" : "") + (f.indent ? " indent" : "")}>
              {f.dir ? "📁 " : (f.indent ? "" : "📄 ")}{f.name}
            </div>
          ))}
        </div>
        <div className="ide-main">
          <div className="ide-tabs">
            <div className="ide-tab active">agent.py</div>
            <div className="ide-tab">config.py</div>
          </div>
          <div className="editor">
            <div className="gutter">{CODE.split("\n").map((_, i) => <div key={i}>{i + 1}</div>)}</div>
            <pre className="editor-code">{CODE}</pre>
          </div>
          <div className="terminal">
            <div className="term-head">터미널</div>
            <div className="term-body">
              <span style={{ color: "#34d399" }}>$ python agent.py</span><br />
              MLflow Agent 등록 시작<br />
              &nbsp;&nbsp;enabled assets: ['prompt', 'rag', 'tool', 'llm']<br />
              <span style={{ color: "#94a3b8" }}>등록 완료: models:/genai_agent/3</span>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
