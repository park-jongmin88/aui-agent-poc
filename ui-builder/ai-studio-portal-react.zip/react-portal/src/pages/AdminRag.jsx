import { useState } from "react";
import { Layout, PageHead, Modal, Field, Tag } from "../components/ui";
import { rags } from "../mock/data";

export default function AdminRag() {
  const [open, setOpen] = useState(false);
  return (
    <Layout>
      <PageHead eyebrow="관리자" title="RAG 관리"
        sub="에이전트가 검색할 지식베이스를 등록·관리합니다."
        right={<button className="btn btn-primary" onClick={() => setOpen(true)}>+ 지식베이스 등록</button>} />

      <div className="card-box">
        <table>
          <thead><tr><th>지식베이스명</th><th>모드</th><th>문서 수</th><th>top_k</th><th>수정일</th><th style={{ width: 90 }}></th></tr></thead>
          <tbody>
            {rags.map((r) => (
              <tr key={r.id}>
                <td style={{ fontWeight: 600 }}>{r.name}</td>
                <td><Tag tone={r.mode === "milvus" ? "green" : "gray"}>{r.mode}</Tag></td>
                <td>{r.docs.toLocaleString()}건</td>
                <td className="muted">{r.topK}</td>
                <td className="muted">{r.updated}</td>
                <td><button className="btn btn-ghost btn-sm" onClick={() => alert("데모: 관리")}>관리</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Modal title="지식베이스 등록" open={open} onClose={() => setOpen(false)}
        onSubmit={() => { setOpen(false); alert("데모: 지식베이스 등록됨"); }}>
        <Field label="지식베이스명"><input className="input" placeholder="예: 제품_매뉴얼" /></Field>
        <Field label="모드"><select className="input"><option>mock (목업)</option><option>milvus (벡터 DB)</option></select></Field>
        <div className="two-col">
          <Field label="top_k"><input className="input" defaultValue="3" /></Field>
          <Field label="문서 업로드"><input className="input" type="file" /></Field>
        </div>
      </Modal>
    </Layout>
  );
}
