import { Layout, PageHead, Tag } from "../components/ui";
import { deployments } from "../mock/data";

export default function Serving() {
  return (
    <Layout>
      <PageHead eyebrow="서빙" title="배포 관리"
        sub="등록된 에이전트를 KServe로 배포하고 상태를 관리합니다." />
      <div className="card-box">
        <table>
          <thead><tr><th>에이전트</th><th>버전</th><th>상태</th><th>엔드포인트</th><th>배포일</th><th style={{ width: 120 }}></th></tr></thead>
          <tbody>
            {deployments.map((r) => (
              <tr key={r.id}>
                <td style={{ fontWeight: 600 }}>{r.agent}</td>
                <td><Tag tone="blue">v{r.version}</Tag></td>
                <td><Tag tone={r.status === "서빙중" ? "green" : "amber"}>{r.status}</Tag></td>
                <td className="mono-sm">{r.endpoint}</td>
                <td className="muted">{r.deployed}</td>
                <td><button className="btn btn-ghost btn-sm" onClick={() => alert("데모: 테스트")}>테스트</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  );
}
