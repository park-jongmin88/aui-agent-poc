import { useState } from "react";
import { Layout, PageHead, Modal, Field, Tag } from "../components/ui";
import { prompts } from "../mock/data";

export default function AdminPrompt() {
  const [open, setOpen] = useState(false);
  return (
    <Layout>
      <PageHead eyebrow="관리자" title="프롬프트 관리"
        sub="사용자에게 제공할 시스템 프롬프트를 등록·관리합니다."
        right={<button className="btn btn-primary" onClick={() => setOpen(true)}>+ 프롬프트 등록</button>} />

      <div className="card-box">
        <table>
          <thead><tr><th>이름</th><th>최신 버전</th><th>설명</th><th>수정일</th><th style={{ width: 90 }}></th></tr></thead>
          <tbody>
            {prompts.map((r) => (
              <tr key={r.id}>
                <td style={{ fontWeight: 600 }}>{r.name}</td>
                <td><Tag tone="blue">v{r.version}</Tag></td>
                <td className="muted">{r.desc}</td>
                <td className="muted">{r.updated}</td>
                <td><button className="btn btn-ghost btn-sm" onClick={() => alert("데모: 관리")}>관리</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Modal title="프롬프트 등록" open={open} onClose={() => setOpen(false)}
        onSubmit={() => { setOpen(false); alert("데모: 프롬프트 등록됨"); }}>
        <Field label="프롬프트 이름"><input className="input" placeholder="예: 고객상담_기본" /></Field>
        <Field label="설명"><input className="input" placeholder="용도를 간단히 적어주세요" /></Field>
        <Field label="시스템 프롬프트 내용"><textarea className="input" placeholder="당신은 친절한 고객상담 Agent 입니다..." /></Field>
      </Modal>
    </Layout>
  );
}
