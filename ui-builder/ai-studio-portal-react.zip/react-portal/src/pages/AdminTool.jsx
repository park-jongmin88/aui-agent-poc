import { useState } from "react";
import { Layout, PageHead, Modal, Field, Tag } from "../components/ui";
import { tools } from "../mock/data";

export default function AdminTool() {
  const [open, setOpen] = useState(false);
  return (
    <Layout>
      <PageHead eyebrow="관리자" title="도구(Tool) 관리"
        sub="에이전트가 호출할 외부 도구(API)를 등록·관리합니다."
        right={<button className="btn btn-primary" onClick={() => setOpen(true)}>+ 도구 등록</button>} />

      <div className="card-box">
        <table>
          <thead><tr><th>도구명</th><th>모드</th><th>트리거 키워드</th><th>엔드포인트</th><th style={{ width: 90 }}></th></tr></thead>
          <tbody>
            {tools.map((r) => (
              <tr key={r.id}>
                <td style={{ fontWeight: 600 }}>{r.name}</td>
                <td><Tag tone={r.mode === "real" ? "green" : "gray"}>{r.mode}</Tag></td>
                <td>{r.keywords.map((k) => <span key={k} className="tag tag-amber" style={{ marginRight: 4 }}>{k}</span>)}</td>
                <td className="mono-sm">{r.endpoint}</td>
                <td><button className="btn btn-ghost btn-sm" onClick={() => alert("데모: 관리")}>관리</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Modal title="도구 등록" open={open} onClose={() => setOpen(false)}
        onSubmit={() => { setOpen(false); alert("데모: 도구 등록됨"); }}>
        <Field label="도구명"><input className="input" placeholder="예: 날씨조회" /></Field>
        <Field label="모드"><select className="input"><option>mock (목업)</option><option>real (실제 API)</option></select></Field>
        <Field label="트리거 키워드"><input className="input" placeholder="쉼표로 구분 (예: 날씨, 기온, 비)" /></Field>
        <Field label="엔드포인트 URL"><input className="input" placeholder="https://api.example.com/weather" /></Field>
      </Modal>
    </Layout>
  );
}
