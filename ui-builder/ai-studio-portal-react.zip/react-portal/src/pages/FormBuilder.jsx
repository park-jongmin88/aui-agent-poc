import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Layout } from "../components/ui";
import { promptOptions, modelOptions } from "../mock/data";

const ACCENT = "#60a5fa";
const ASSET_META = {
  prompt: { label: "프롬프트", desc: "시스템 프롬프트 로드" },
  rag: { label: "RAG", desc: "지식베이스 검색" },
  tool: { label: "도구", desc: "외부 API 호출" },
  llm: { label: "LLM", desc: "답변 생성 (필수)" },
};

export default function FormBuilder() {
  const nav = useNavigate();
  const [name, setName] = useState("my-agent");
  const [assets, setAssets] = useState({ prompt: true, rag: true, tool: true, llm: true });
  const [prompt, setPrompt] = useState(promptOptions[0]);
  const [ver, setVer] = useState(2);
  const [model, setModel] = useState(modelOptions[0]);
  const [ragMode, setRagMode] = useState("mock");
  const [toolMode, setToolMode] = useState("mock");

  const toggle = (k) => k !== "llm" && setAssets((a) => ({ ...a, [k]: !a[k] }));
  const enabled = Object.keys(assets).filter((k) => assets[k]);

  const cfg = [
    `# ${name}/config.py  (자동 생성)`, ``,
    `ENABLED_ASSETS = [${enabled.map((e) => `"${e}"`).join(", ")}]`, ``,
    `LLM_MODEL = "${model}"`, ``,
    `ASSET_CONN = {`,
    assets.prompt ? `    "prompt": {"name": "${prompt}", "version": ${ver}},` : null,
    assets.rag ? `    "rag":    {"mode": "${ragMode}", "top_k": 3},` : null,
    assets.tool ? `    "tool":   {"mode": "${toolMode}"},` : null,
    `}`,
  ].filter((l) => l !== null).join("\n");

  const Seg = ({ value, onChange, options }) => (
    <div className="seg">
      {options.map(([v, l]) => (
        <button key={v} className="seg-btn"
          style={value === v ? { background: ACCENT, color: "#fff" } : null}
          onClick={() => onChange(v)}>{l}</button>
      ))}
    </div>
  );

  return (
    <Layout>
      <div className="page-head">
        <button className="back-link" onClick={() => nav("/")}>← 방식 선택</button>
        <div className="head-row">
          <div className="bhead-title">
            <span className="bhead-step" style={{ color: ACCENT }}>01</span>
            <h1 className="h1" style={{ margin: 0 }}>폼 빌더</h1>
            <span className="sc-who" style={{ background: "#eff6ff", color: ACCENT }}>처음 만드는 사용자</span>
          </div>
          <button className="btn btn-primary" style={{ background: ACCENT }}
            onClick={() => alert("데모: 에이전트 등록 → MLflow")}>에이전트 등록 →</button>
        </div>
      </div>

      <div className="fb-split">
        <div>
          <div className="fb-section">
            <h3 className="fb-stitle">기본 정보</h3>
            <label className="field"><span className="field-label">에이전트 이름</span>
              <input className="input" value={name} onChange={(e) => setName(e.target.value)} /></label>
          </div>

          <div className="fb-section">
            <h3 className="fb-stitle">에셋 선택</h3>
            <div className="asset-grid">
              {Object.keys(ASSET_META).map((k) => {
                const on = assets[k], locked = k === "llm";
                return (
                  <button key={k} className={"asset-card" + (locked ? " locked" : "")}
                    onClick={() => toggle(k)}
                    style={on ? { borderColor: ACCENT, background: "#eff6ff" } : null}>
                    <div className="asset-top">
                      <span className="asset-check"
                        style={on ? { borderColor: ACCENT, background: ACCENT, color: "#fff" } : null}>
                        {on ? "✓" : ""}</span>
                      <span className="asset-label">{ASSET_META[k].label}</span>
                      {locked && <span className="lock-tag">필수</span>}
                    </div>
                    <p className="asset-desc">{ASSET_META[k].desc}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {assets.prompt && (
            <div className="fb-section">
              <h3 className="fb-stitle">프롬프트</h3>
              <div className="two-col">
                <label className="field"><span className="field-label">프롬프트 선택</span>
                  <select className="input" value={prompt} onChange={(e) => setPrompt(e.target.value)}>
                    {promptOptions.map((p) => <option key={p}>{p}</option>)}
                  </select></label>
                <label className="field"><span className="field-label">버전</span>
                  <select className="input" value={ver} onChange={(e) => setVer(+e.target.value)}>
                    {[1, 2, 3].map((v) => <option key={v} value={v}>v{v}</option>)}
                  </select></label>
              </div>
            </div>
          )}

          {assets.rag && (
            <div className="fb-section">
              <h3 className="fb-stitle">RAG</h3>
              <Seg value={ragMode} onChange={setRagMode} options={[["mock", "목업"], ["milvus", "Milvus 연결"]]} />
            </div>
          )}

          {assets.tool && (
            <div className="fb-section">
              <h3 className="fb-stitle">도구(Tool)</h3>
              <Seg value={toolMode} onChange={setToolMode} options={[["mock", "목업"], ["real", "실제 API"]]} />
            </div>
          )}

          <div className="fb-section">
            <h3 className="fb-stitle">모델</h3>
            <label className="field"><span className="field-label">LLM 모델</span>
              <select className="input" value={model} onChange={(e) => setModel(e.target.value)}>
                {modelOptions.map((m) => <option key={m}>{m}</option>)}
              </select></label>
          </div>
        </div>

        <div className="fb-preview">
          <div className="prev-head">
            <span className="prev-dot" /><span className="prev-dot" /><span className="prev-dot" />
            <span className="prev-name">config.py</span>
            <span className="prev-badge">실시간 미리보기</span>
          </div>
          <pre className="prev-code">{cfg}</pre>
        </div>
      </div>
    </Layout>
  );
}
