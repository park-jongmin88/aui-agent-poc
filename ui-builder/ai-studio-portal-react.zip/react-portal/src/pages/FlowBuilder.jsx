import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Layout } from "../components/ui";

const ACCENT = "#2dd4bf";
const NODES = [
  { id: "in", label: "입력", x: 40, y: 130, c: "#94a3b8" },
  { id: "prompt", label: "프롬프트", x: 220, y: 60, c: "#60a5fa" },
  { id: "rag", label: "RAG 검색", x: 220, y: 200, c: "#f59e0b" },
  { id: "llm", label: "LLM", x: 430, y: 130, c: "#2dd4bf" },
  { id: "out", label: "출력", x: 620, y: 130, c: "#94a3b8" },
];
const EDGES = [["in", "prompt"], ["in", "rag"], ["prompt", "llm"], ["rag", "llm"], ["llm", "out"]];
const NW = 130, NH = 56;
const FLOWISE_URL = ""; // docker로 Flowise 띄운 뒤 "http://localhost:3000" 입력

export default function FlowBuilder() {
  const nav = useNavigate();
  const [useFlowise, setUseFlowise] = useState(false);
  const byId = Object.fromEntries(NODES.map((n) => [n.id, n]));
  const center = (n) => ({ x: n.x + NW / 2, y: n.y + NH / 2 });

  return (
    <Layout>
      <div className="page-head">
        <button className="back-link" onClick={() => nav("/")}>← 방식 선택</button>
        <div className="head-row">
          <div className="bhead-title">
            <span className="bhead-step" style={{ color: ACCENT }}>03</span>
            <h1 className="h1" style={{ margin: 0 }}>플로우 빌더</h1>
            <span className="sc-who" style={{ background: "#f0fdfa", color: ACCENT }}>흐름 중심의 기획자</span>
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <button className="btn btn-ghost"
              onClick={() => setUseFlowise((v) => !v)}>
              {useFlowise ? "내장 캔버스 보기" : "Flowise 연결 보기"}
            </button>
            <button className="btn btn-primary" style={{ background: ACCENT }}
              onClick={() => alert("데모: 플로우 → config 변환")}>에이전트로 변환 →</button>
          </div>
        </div>
      </div>

      {useFlowise ? (
        <div className="flow" style={{ gridTemplateColumns: "1fr" }}>
          {FLOWISE_URL ? (
            <iframe title="Flowise" src={FLOWISE_URL} style={{ width: "100%", height: "100%", border: "none" }} />
          ) : (
            <div className="flow-iframe-note">
              <div className="big">Flowise 캔버스 연결 자리</div>
              <p className="sub" style={{ maxWidth: 480 }}>
                아래 명령으로 Flowise를 띄운 뒤, FlowBuilder.jsx의 FLOWISE_URL에
                주소를 넣으면 이 영역에 노드 편집기가 임베드됩니다.
              </p>
              <code className="cmd">docker run -d -p 3000:3000 flowiseai/flowise</code>
              <p className="sub" style={{ fontSize: 13 }}>인증·권한은 포탈이 처리하고 Flowise는 빌더로만 사용합니다.</p>
            </div>
          )}
        </div>
      ) : (
        <div className="flow">
          <div className="palette">
            <div className="palette-head">노드</div>
            {["프롬프트", "RAG 검색", "도구 호출", "LLM", "출력"].map((p) => (
              <div key={p} className="palette-item">⠿ {p}</div>
            ))}
          </div>
          <div className="canvas">
            <svg className="flow-svg">
              {EDGES.map(([a, b], i) => {
                const p = center(byId[a]), q = center(byId[b]);
                const mx = (p.x + q.x) / 2;
                return <path key={i}
                  d={`M ${p.x + NW / 2} ${p.y} C ${mx} ${p.y}, ${mx} ${q.y}, ${q.x - NW / 2} ${q.y}`}
                  stroke="#cbd5e1" strokeWidth="2" fill="none" />;
              })}
            </svg>
            {NODES.map((n) => (
              <div key={n.id} className="node" style={{ left: n.x, top: n.y, borderColor: n.c }}>
                <span className="node-dot" style={{ background: n.c }} />{n.label}
              </div>
            ))}
          </div>
          <div className="props">
            <div className="props-head">속성 · LLM</div>
            <label className="field"><span className="field-label">모델</span>
              <select className="input"><option>Qwen2.5-72B</option><option>Llama-3.1-70B</option></select></label>
            <label className="field"><span className="field-label">Temperature</span><input className="input" defaultValue="0" /></label>
            <label className="field"><span className="field-label">Max Tokens</span><input className="input" defaultValue="2048" /></label>
            <div className="props-note">노드를 클릭하면 해당 속성이 여기 표시됩니다.</div>
          </div>
        </div>
      )}
    </Layout>
  );
}
