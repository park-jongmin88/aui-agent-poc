// =============================================================
// 목데이터 (DB/서버 없이 프론트 내장)
// 실제 API 연동 시 이 파일의 export 들을 fetch 로 바꾸면 됩니다.
//   예) export const getPrompts = () => fetch('/api/prompts').then(r=>r.json())
// =============================================================

export const prompts = [
  { id: 1, name: "고객상담_기본", version: 3, desc: "고객 문의 응대용 기본 프롬프트", updated: "2026-06-20" },
  { id: 2, name: "사내문서_QA", version: 2, desc: "사내 규정/문서 질의응답", updated: "2026-06-18" },
  { id: 3, name: "코드리뷰_도우미", version: 5, desc: "PR 코드 리뷰 보조", updated: "2026-06-22" },
];

export const rags = [
  { id: 1, name: "제품_매뉴얼", mode: "mock", docs: 42, topK: 3, updated: "2026-06-19" },
  { id: 2, name: "사내_규정집", mode: "milvus", docs: 318, topK: 5, updated: "2026-06-21" },
  { id: 3, name: "FAQ_모음", mode: "mock", docs: 87, topK: 3, updated: "2026-06-15" },
];

export const tools = [
  { id: 1, name: "날씨조회", mode: "mock", keywords: ["날씨", "기온", "비"], endpoint: "—" },
  { id: 2, name: "사번조회", mode: "real", keywords: ["사번", "직원", "연락처"], endpoint: "https://hr.api/emp" },
  { id: 3, name: "재고확인", mode: "mock", keywords: ["재고", "수량", "입고"], endpoint: "—" },
];

export const models = [
  { id: 1, name: "Qwen2.5-72B", baseUrl: "http://vllm-qwen:8000/v1", status: "정상", created: "2026-06-10" },
  { id: 2, name: "Llama-3.1-70B", baseUrl: "http://vllm-llama:8000/v1", status: "정상", created: "2026-06-12" },
  { id: 3, name: "Mistral-Large", baseUrl: "http://vllm-mistral:8000/v1", status: "점검중", created: "2026-06-14" },
];

export const deployments = [
  { id: 1, agent: "customer-agent", version: 3, status: "서빙중", endpoint: "/v1/models/customer-agent", deployed: "2026-06-22" },
  { id: 2, agent: "doc-qa-agent", version: 2, status: "서빙중", endpoint: "/v1/models/doc-qa-agent", deployed: "2026-06-20" },
  { id: 3, agent: "code-review-agent", version: 5, status: "배포대기", endpoint: "—", deployed: "2026-06-23" },
];

export const evaluations = [
  { id: "eval-0042", agent: "customer-agent v3", samples: 120, score: 4.4, ran: "2026-06-23" },
  { id: "eval-0041", agent: "doc-qa-agent v2", samples: 80, score: 4.1, ran: "2026-06-21" },
  { id: "eval-0040", agent: "customer-agent v2", samples: 120, score: 3.9, ran: "2026-06-18" },
];

export const evalSummary = [
  { label: "정확성", value: 4.6, color: "#10b981" },
  { label: "관련성", value: 4.8, color: "#10b981" },
  { label: "유해성", value: 0.1, color: "#10b981" },
  { label: "전체 평균", value: 4.4, color: "#3b82f6" },
];

// 폼 빌더 옵션
export const promptOptions = ["고객상담_기본", "사내문서_QA", "코드리뷰_도우미"];
export const modelOptions = ["Qwen2.5-72B", "Llama-3.1-70B", "Mistral-Large"];
